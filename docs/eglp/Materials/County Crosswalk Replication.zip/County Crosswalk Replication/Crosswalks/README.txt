The scripts write the crosswalks to this folder.
