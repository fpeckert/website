This archive is kept so that old links keep working. The current files, including Stata versions
of the crosswalks, are in the GitHub repository: https://github.com/liang-jack-a/EGLP_Crosswalk

Replication code for the county and commuting zone crosswalks of Eckert, Gvirtz, Liang and Peters (2020), www.fpeckert.me/eglp.

1. pip install -r requirements.txt  (Python 3.10 or later)
2. Put the shapefiles in Shapefiles/ as described in Shapefiles/HowToAcquireShapeFiles.txt.
3. From this folder run:
     python Code/crosswalk_county.py --end-year 1990
     python Code/crosswalk_county.py --end-year 2010
     python Code/crosswalk_cz.py
   The crosswalks are written to Crosswalks/.
4. To compare a rebuilt crosswalk with the posted one:
     python Code/check_crosswalks.py eglp_county_crosswalk_endyr_2010.csv Crosswalks/county_crosswalk_endyr_2010.csv 2010
5. To write Stata versions of the crosswalks into Crosswalks/Stata/:
     python Code/make_stata_files.py
