This archive is kept so that old links keep working. The current files, including Stata versions
of the crosswalks, are in the GitHub repository: https://github.com/liang-jack-a/EGLP_Crosswalk

Put eglp_county_crosswalk_endyr_2010.csv from www.fpeckert.me/eglp, or county_crosswalk_endyr_2010.csv from GitHub, in this folder,
then run python Example/crosswalk_example.py from the Use Example folder.
For the Stata version, put Stata/county_crosswalk_endyr_2010.dta.zip from GitHub in Crosswalks/Stata/ and run do Example/crosswalk_example.do.
